// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define cmdTabSistema 2 
#define cmdTabSistema_LabelTitle_RESID 60001
#define cmdTabEditar 3 
#define cmdTabEditar_LabelTitle_RESID 60002
#define cmdTabConceitual 4 
#define cmdTabConceitual_LabelTitle_RESID 60003
#define cmdTabLogico 5 
#define cmdTabLogico_LabelTitle_RESID 60004
#define cmdTabConfiguracao 6 
#define cmdTabConfiguracao_LabelTitle_RESID 60005
#define cmdGroupNovo 7 
#define cmdGroupNovo_LabelTitle_RESID 60006
#define cmdGroupArquivo 8 
#define cmdGroupArquivo_LabelTitle_RESID 60007
#define cmdGroupExportacao 9 
#define cmdGroupExportacao_LabelTitle_RESID 60008
#define cmdGroupImpressao 10 
#define cmdGroupImpressao_LabelTitle_RESID 60009
#define cmdGroupOpcoes 11 
#define cmdGroupOpcoes_LabelTitle_RESID 60010
#define cmdGroupFerramentasConceitual 12 
#define cmdGroupFerramentasConceitual_LabelTitle_RESID 60011
#define cmdGroupFerramentasLogico 13 
#define cmdGroupFerramentasLogico_LabelTitle_RESID 60012
#define cmdGroupComandosConceitual 14 
#define cmdGroupComandosConceitual_LabelTitle_RESID 60013
#define cmdGroupComandosLogico 15 
#define cmdGroupComandosLogico_LabelTitle_RESID 60014
#define cmdNovoConceitual 16 
#define cmdNovoConceitual_LabelTitle_RESID 60015
#define cmdNovoLogico 17 
#define cmdNovoLogico_LabelTitle_RESID 60016
#define cmdAbrir 18 
#define cmdAbrir_LabelTitle_RESID 60017
#define cmdSalvar 19 
#define cmdSalvar_LabelTitle_RESID 60018
#define cmdSalvarComo 20 
#define cmdSalvarComo_LabelTitle_RESID 60019
#define cmdFechar 21 
#define cmdFechar_LabelTitle_RESID 60020
#define cmdExportarJPEG 22 
#define cmdExportarJPEG_LabelTitle_RESID 60021
#define cmdExportarBMP 23 
#define cmdExportarBMP_LabelTitle_RESID 60022
#define cmdImprimir 24 
#define cmdImprimir_LabelTitle_RESID 60023
#define cmdGerarDicionario 25 
#define cmdGerarDicionario_LabelTitle_RESID 60024
#define cmdAjuda 26 
#define cmdAjuda_LabelTitle_RESID 60025
#define cmdConfiguracoes 27 
#define cmdConfiguracoes_LabelTitle_RESID 60026
#define cmdCancelarConceitual 28 
#define cmdCancelarConceitual_LabelTitle_RESID 60027
#define cmdCancelarLogico 29 
#define cmdCancelarLogico_LabelTitle_RESID 60028
#define cmdAutoSalvar 30 
#define cmdAutoSalvar_LabelTitle_RESID 60029
#define InternalCmd2_LabelTitle_RESID 60030
