// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define cmdTabArquivo 2 
#define cmdTabArquivo_LabelTitle_RESID 60001
#define cmdGroupOpcoes 3 
#define cmdGroupOpcoes_LabelTitle_RESID 60002
#define cmdSalvarComo 4 
#define cmdSalvarComo_LabelTitle_RESID 60003
#define cmdSalvarComo_SmallImages_RESID 60004
#define cmdSalvarComo_LargeImages_RESID 60005
#define cmdFechar 5 
#define cmdFechar_LabelTitle_RESID 60006
#define cmdFechar_SmallImages_RESID 60007
#define cmdFechar_LargeImages_RESID 60008
#define InternalCmd2_LabelTitle_RESID 60009
